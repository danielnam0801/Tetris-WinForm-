﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris_10404남준성
{
    internal class GameRule
    {
        internal const int B_Width = 30;
        internal const int B_Height = 30;
        internal const int BX = 12;
        internal const int BY = 20;
        internal const int SX = 4;
        internal const int SY = 0;

    }
}
